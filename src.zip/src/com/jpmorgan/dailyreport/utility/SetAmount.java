/**
 * 
 */
package com.jpmorgan.dailyreport.utility;

/**
 * @author MANISHA
 *
 */
public interface SetAmount {

	double calculateAmount(double price, int units, double agreedFx);
}
