/**
 * 
 */
package com.jpmorgan.dailyreport.bean;

/**
 * @author MANISHA
 *
 */
public enum Indicator {

	BUY,
	SELL
}
