/**
 * 
 */
package com.jpmorgan.dailyreport.bean;

/**
 * @author MANISHA
 *
 */
public enum Currency {

	AED,
	SGP,
	GBP,
	INR
}
